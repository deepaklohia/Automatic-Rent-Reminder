#define BLYNK_TEMPLATE_ID "x"
#define BLYNK_TEMPLATE_NAME "xx SPEAKER"
#define BLYNK_FIRMWARE_VERSION "1.2.3"

//#define BLYNK_PRINT Serial
//#define BLYNK_DEBUG
//#define APP_DEBUG

/*
28-8-2025 Fixing update for next and pre track
7-9-2025  re-adjusted timinings
9-9-2025  removed vol up and down and timeout / start stop
18-9-2025 default off on every play
15-10-2025 playdefault changed to true by default  
17-10-2025 auto play arti and removed play default button
7-11-2025 added button to turn off BLYNK MESSAGES , 5SEC WAIT ,, added last update , added track button for easy automation
11-11-2025 simplified . to make track auto play in 15 secs after selection , 30 sec update time
*/

// Uncomment your board, or configure a custom board in Settings.h
//#define USE_SPARKFUN_BLYNK_BOARD
#define USE_NODE_MCU_BOARD
//#define USE_WITTY_CLOUD_BOARD
//#define USE_WEMOS_D1_MINI

#define ER_OFF HIGH
#define ER_ON LOW 

#define VPIN_AUDIO_POWER      V0  //MODE POWER
#define VPIN_TRACK_NUMBER     V1 // TRACK NUMBER
#define VPIN_PLAY_TRACK       V2 //PLAY TRACK
#define VPIN_INFO             V3 // info display
#define VPIN_REDUCE_VOL_SW    V5
#define VPIN_TIME_STAMP       V9
//#define VPIN_PLAY_DEFAULT     V6 //play default
#define VPIN_BLYNK_MESSAGE    V15

const char trackList[][30] PROGMEM = {
  "0000 - Blank",
  "0001 - Lata Ji ONS",
  "0002 - Aarti, Chalisa",
  "0003 - ONS Dhun",
  "0004 - Banke Bihari Aarti",
  "0005 - Suno Suno Shri Ram",
  "0006 - Aalah Hanuman Ji",
  "0007 - Bam Lehri",
  "0008 - Aisi Lagi Lagan",
  "0009 - Hey Raam Dhun",
  "0010 - Hanuman Chalisa",
  "0011 - Shree Hanumaan Aarti",
  "0012 - Deepak Lohia Bhajan",
  "0013 - Aarati, Raam Kahani",
  "0014 - Hare Rama Jagjit",
  "0015 - Max Reached"
  //"0000 - Sundar Kand",
};

#include "BlynkEdgent.h"
#include <WidgetRTC.h>
#include <TimeLib.h>

//D1 ARDIUNO BASED
static const uint8_t D2   = 16; //SAFE TO USE? --- HIGH ON BOOT ??
static const uint8_t D5   = 14; //SAFE TO USE? --- HIGH ON BOOT ??
static const uint8_t D6   = 12; //SAFE TO USE?
static const uint8_t D7   = 13; //SAFE TO USE?

int const relayPin_AMP_POWER = D6; 
int const relayPin_NEXT_TRK = D7;
int const relayPin_PRE_TRK = D2 ;
int const relayPin_MOD_POWER = D5 ; 
bool audioPowerState= false;
bool adjVolume= false;
unsigned long volRelayTimeMilli = 500;
int currentTrack = 1 ;
int defaultTrack = 13;
bool playSwitch= false; 
String CurrentTrackName = "Starting...";
int lastTrackNumber = 0;
bool runOnceTrack = false;
bool runOnceClock = false;
bool blynkMsg = false;   
bool firstConnect = false ;
const int BLYNK_MAX_CYCLE = 2; 
int blynkMsgCounter = BLYNK_MAX_CYCLE;
bool trackEditMode = false;
unsigned long trackEditStart = 0;
bool lastAudioPowerState = false;
String lastInfo = "";


BlynkTimer timer;
WidgetRTC rtc;

BLYNK_CONNECTED(){
  if (!firstConnect) {
    Blynk.virtualWrite(VPIN_INFO, "<STARTING...>");
    Blynk.virtualWrite(VPIN_AUDIO_POWER, 0);    //DEFAULT POWER OFF
    Blynk.virtualWrite(VPIN_TRACK_NUMBER, defaultTrack);  //SETTING DEFAULT
    Blynk.virtualWrite(VPIN_PLAY_TRACK, 0);     //DEFAULT PLAY OFF
    Blynk.virtualWrite(VPIN_REDUCE_VOL_SW, 0);  //DEFAULT VOL REDUCE SWITCH OFF
    firstConnect = true;
  }
  Blynk.syncVirtual(VPIN_AUDIO_POWER);
  Blynk.syncVirtual(VPIN_TRACK_NUMBER);
  Blynk.syncVirtual(VPIN_INFO);
  Blynk.syncVirtual(VPIN_PLAY_TRACK);
  Blynk.syncVirtual(VPIN_REDUCE_VOL_SW);
  Blynk.syncVirtual(VPIN_TIME_STAMP);
  Blynk.syncVirtual(VPIN_BLYNK_MESSAGE);
  Blynk.sendInternal("rtc", "sync"); //request current local time for device
}

BLYNK_WRITE(VPIN_AUDIO_POWER){ if (param.asInt()){ powerAudioModule(true) ; }else {powerAudioModule(false); }}
BLYNK_WRITE(VPIN_TRACK_NUMBER){ currentTrack = param.asInt();  if (currentTrack != lastTrackNumber) {  trackEditMode = true;  trackEditStart = millis(); }}
BLYNK_WRITE(VPIN_PLAY_TRACK){if (param.asInt()){  playTrack(); Blynk.virtualWrite(VPIN_PLAY_TRACK, 0); }} 
BLYNK_WRITE(VPIN_REDUCE_VOL_SW){adjVolume = param.asInt(); }
BLYNK_WRITE(VPIN_BLYNK_MESSAGE) {blynkMsg = param.asInt(); if (!blynkMsg){ blynkMsgCounter = BLYNK_MAX_CYCLE;} }

void setup(){
  Serial.begin(115200);
  delay(100);
  BlynkEdgent.begin();

  pinMode(relayPin_AMP_POWER, OUTPUT);
  pinMode(relayPin_NEXT_TRK, OUTPUT);
  pinMode(relayPin_PRE_TRK, OUTPUT);
  pinMode(relayPin_MOD_POWER, OUTPUT);

  digitalWrite(relayPin_AMP_POWER, ER_OFF);
  digitalWrite(relayPin_NEXT_TRK, ER_OFF);
  digitalWrite(relayPin_PRE_TRK, ER_OFF);
  digitalWrite(relayPin_MOD_POWER, ER_OFF);
  setSyncInterval(60 * 60); // 1 hour
  timer.setInterval(1000L, runLogic);

  lastTrackNumber = defaultTrack ;
  blynkMsgCounter = BLYNK_MAX_CYCLE;
  //defaultTrackStartTime = millis();
}

void loop(){
  BlynkEdgent.run();  timer.run(); 
}

void runLogic(){
  if (year() > 2020 && !runOnceClock){
    String currentDate = String(day()) + "-" + getMonthStr(month()) + "-" + year();
    Blynk.virtualWrite(VPIN_TIME_STAMP, currentDate + " " + getTimeAMPM()); 
    runOnceClock = true ;
    /*IF CLOCK SYNCED*/
    currentTrack = defaultTrack; playTrack(); 
  }
  
  //if (!runOnceTrack && runOnceClock &&  millis() - defaultTrackStartTime > 15000UL) {    currentTrack = defaultTrack;  playTrack();  runOnceTrack = true;  } /*DEFAULT TRACK PLAY*/
  if (trackEditMode && runOnceClock) { if (millis() - trackEditStart > 15000UL) {  trackEditMode = false; playTrack();  } }/*TRACK TIMEOUT*/
  
 // Send values only if allowed
  if (blynkMsg || blynkMsgCounter < BLYNK_MAX_CYCLE) {
    if (!blynkMsg) blynkMsgCounter++;
    
    if (lastAudioPowerState != audioPowerState) { Blynk.virtualWrite(VPIN_AUDIO_POWER, audioPowerState); lastAudioPowerState = audioPowerState;}
    //if (lastTrackNumberBlynk != currentTrack) { Blynk.virtualWrite(VPIN_TRACK_NUMBER, currentTrack);lastTrackNumberBlynk = currentTrack;    }

    String infoStr = audioPowerState ?  (playSwitch ? "PLAYING>  " : "PLAYING>> ") + CurrentTrackName  : "<STAND BY...>";         
    //String infoStr = audioPowerState ? CurrentTrackName : "<STAND BY...>";      
    if (infoStr != lastInfo) { Blynk.virtualWrite(VPIN_INFO, infoStr); lastInfo = infoStr; }
    if (audioPowerState) playSwitch = !playSwitch; // toggle only if playin
  }
}

void playTrack() {
  blynkMsgCounter = 0; //whenever a track play
  lastTrackNumber = currentTrack;

  if (audioPowerState) { powerAudioModule(false);  delay(5000); }
  //powerAudioModule(false);  delay(5000);
  powerAudioModule(true); 
  if (adjVolume){reduceVolume(); }
  startTrack();  delay(1000);
  if (currentTrack >= 2){locateTrack(currentTrack-1); }  //change track
  
  //set track name
  char buffer[31]; 
  strcpy_P(buffer, trackList[currentTrack]);
  CurrentTrackName = String(buffer).substring(0, 25);
}

void startTrack(){ 
  delay(500);
  digitalWrite(relayPin_NEXT_TRK, ER_ON); delay(300);
  digitalWrite(relayPin_NEXT_TRK, ER_OFF); delay(200);
}

void locateTrack(int loop){
  for (int i = 0; i <loop; i++){
    delay(500);
    digitalWrite(relayPin_NEXT_TRK, ER_ON); delay(300);
    digitalWrite(relayPin_NEXT_TRK, ER_OFF); delay(1200);
    digitalWrite(relayPin_NEXT_TRK, ER_ON); delay(300);
    digitalWrite(relayPin_NEXT_TRK, ER_OFF); delay(400);
  }
}

void reduceVolume(){
  delay(1500);  digitalWrite(relayPin_PRE_TRK, ER_ON);
  delay(volRelayTimeMilli);  digitalWrite(relayPin_PRE_TRK, ER_OFF);  delay(500);
}

void powerAudioModule(bool requestedState){
  if (requestedState){    digitalWrite(relayPin_MOD_POWER, ER_ON);     digitalWrite(relayPin_AMP_POWER, ER_ON);    audioPowerState = true ;
  }else {digitalWrite(relayPin_MOD_POWER, ER_OFF);     digitalWrite(relayPin_AMP_POWER, ER_OFF);    audioPowerState = false ;    delay(2000);  }
  delay(1000);
}

String padZero(int val){  if (val < 10){ return "0" + String(val);}  else{  return String(val); }}

String getMonthStr(int m){  const char* arr[] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};  return String(arr[m - 1]);}

String getTimeAMPM() {  int hr = hour();  String ampm = (hr >= 12) ? "PM" : "AM";  if (hr == 0) hr = 12;  else if (hr > 12) hr -= 12;  return String(padZero(hr)) + ":" + padZero(minute()) + " " + ampm;}